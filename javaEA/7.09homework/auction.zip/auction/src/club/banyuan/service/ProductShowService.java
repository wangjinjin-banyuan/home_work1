package club.banyuan.service;

import club.banyuan.entity.Product;
import java.util.List;

public interface ProductShowService {
  public List<Product> getShowProduct() throws Exception;
}
